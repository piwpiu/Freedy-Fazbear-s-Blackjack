import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.net.URL;

public class AboutMenu extends JFrame implements ActionListener {
    private static JLabel pic, meet, arifDesc, kahfiDesc, rafiDesc, azkalDesc, akbarDesc, title, descTitle;
    private static JButton buttonEx;

    public AboutMenu() throws IOException {
        setTitle("About");
        setSize(600, 600);
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        addWindowListener(new CustomWindowAdapter());
        // Create a scroll pane
        JScrollPane scrollPane = new JScrollPane();
        add(scrollPane);

        // Disable horizontal scrolling
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        // Create a panel to hold your content
        JPanel contentPane = new JPanel();
        contentPane.setLayout(null);
        contentPane.setPreferredSize(new Dimension(600, 2181)); // Set the preferred size to your content size
        contentPane.setBackground(new Color(53,101,77));

        title = new JLabel("ABOUT");
        title.setBounds(200, 60, 250, 70);
        title.setFont(new Font("Arial", Font.BOLD, 50)); // Set the font size here
        title.setForeground(Color.white); // Set the font color
        contentPane.add(title);

        descTitle = new JLabel("<html>Blackjack, juga dikenal sebagai 21,<br>" +
                "adalah permainan kartu yang<br>" +
                "populer di kasino. Tujuan utama<br>" +
                "dalam permainan ini adalah untuk<br>" +
                "mengumpulkan kartu dengan total<br>" +
                "nilai sebanyak mungkin, tetapi<br>" +
                "tidak melebihi 21. Permainan ini<br>" +
                "biasanya dimainkan dengan satu<br>" +
                "atau lebih setumpuk kartu standar,<br>" +
                "dan setiap kartu memiliki nilai<br>" +
                "numeriknya sendiri.</html>"
        );
        descTitle.setBounds(50, 184, 500, 396);
        descTitle.setFont(new Font("Bahnschrift", Font.PLAIN, 26)); // Set the font size here
        descTitle.setForeground(Color.white); // Set the font color
        contentPane.add(descTitle);

        meet = new JLabel("MEET THE TEAM");
        meet.setBounds(92, 815, 496, 72);
        meet.setFont(new Font("Bahnschrift", Font.BOLD, 50)); // Set the font size here
        meet.setForeground(Color.WHITE); // Set the font color
        contentPane.add(meet);

        ImageIcon imageArif = createImageIcon("./credits/arif.png");
        if (imageArif != null) {
            pic = new JLabel(imageArif);
            pic.setBounds(50, 967, 150, 150);

            // Add mouse listener to the JLabel
            pic.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    // Open the link in the default web browser when the image is clicked
                    openLink("https://www.instagram.com/arifwrwn");
                }

                @Override
                public void mouseEntered(MouseEvent e) {
                    // Change cursor to hand when the mouse enters the JLabel
                    setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    // Change cursor back to default when the mouse exits the JLabel
                    setCursor(Cursor.getDefaultCursor());
                }
            });

            contentPane.add(pic);
        } else {
            System.err.println("Could not load the image");
        }

        arifDesc = new JLabel("<html>Arif Wirawan<br>" +
                "2210511004<br><br>" +
                "Roles:<br>" +
                "1. Lead Designer<br>" +
                "2. Error Handler</html>");
        arifDesc.setBounds(233, 949, 310, 150);
        arifDesc.setFont(new Font("Bahnschrift", Font.PLAIN, 16));
        arifDesc.setForeground(Color.WHITE);
        contentPane.add(arifDesc);

        ImageIcon imageKahfi = createImageIcon("./credits/kahfi.png");
        if (imageKahfi != null) {
            pic = new JLabel(imageKahfi);
            pic.setBounds(50, 1197, 150, 150);

            // Add mouse listener to the JLabel
            pic.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    // Open the link in the default web browser when the image is clicked
                    openLink("https://www.instagram.com/kuahfi");
                }

                @Override
                public void mouseEntered(MouseEvent e) {
                    // Change cursor to hand when the mouse enters the JLabel
                    setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    // Change cursor back to default when the mouse exits the JLabel
                    setCursor(Cursor.getDefaultCursor());
                }
            });

            contentPane.add(pic);
        } else {
            System.err.println("Could not load the image");
        }

        kahfiDesc = new JLabel("<html>Muhammad Kahfi Darmawan<br>" +
                "2210511007<br><br>" +
                "Roles:<br>" +
                "1. Quality Assurance<br>" +
                "2. Lead UI/UX</html>");
        kahfiDesc.setBounds(233, 1179, 310, 150);
        kahfiDesc.setFont(new Font("Bahnschrift", Font.PLAIN, 16));
        kahfiDesc.setForeground(Color.WHITE);
        contentPane.add(kahfiDesc);

        ImageIcon imageRafi = createImageIcon("./credits/rafi.png");
        if (imageRafi != null) {
            pic = new JLabel(imageRafi);
            pic.setBounds(50, 1427, 150, 150);
            // Add mouse listener to the JLabel
            pic.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    // Open the link in the default web browser when the image is clicked
                    openLink("https://www.instagram.com/mrafirmdhni");
                }
                @Override
                public void mouseEntered(MouseEvent e) {
                    // Change cursor to hand when the mouse enters the JLabel
                    setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                }
                @Override
                public void mouseExited(MouseEvent e) {
                    // Change cursor back to default when the mouse exits the JLabel
                    setCursor(Cursor.getDefaultCursor());
                }
            });
            contentPane.add(pic);
        } else {
            System.err.println("Could not load the image");
        }
        rafiDesc = new JLabel("<html>Muhamad Rafi Ramdhani<br>" +
                "2210511019<br><br>" +
                "Roles:<br>" +
                "1. Lead File Management<br>" +
                "2. Error Handler</html>");
        rafiDesc.setBounds(233, 1409, 310, 150);
        rafiDesc.setFont(new Font("Bahnschrift", Font.PLAIN, 16));
        rafiDesc.setForeground(Color.WHITE);
        contentPane.add(rafiDesc);

        ImageIcon imageAzkal = createImageIcon("./credits/azkal.png");
        if (imageAzkal != null) {
            pic = new JLabel(imageAzkal);
            pic.setBounds(50, 1657, 150, 150);
            // Add mouse listener to the JLabel
            pic.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    // Open the link in the default web browser when the image is clicked
                    openLink("https://www.instagram.com/azkalazkiaaa");
                }
                @Override
                public void mouseEntered(MouseEvent e) {
                    // Change cursor to hand when the mouse enters the JLabel
                    setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                }
                @Override
                public void mouseExited(MouseEvent e) {
                    // Change cursor back to default when the mouse exits the JLabel
                    setCursor(Cursor.getDefaultCursor());
                }
            });
            contentPane.add(pic);
        } else {
            System.err.println("Could not load the image");
        }
        azkalDesc = new JLabel("<html>Muhammad Azkal Azkia<br>" +
                "2210511038<br><br>" +
                "Roles:<br>" +
                "1. UI/UX Designer<br>" +
                "2. Back-End Programmer</html>");
        azkalDesc.setBounds(233, 1639, 310, 150);
        azkalDesc.setFont(new Font("Bahnschrift", Font.PLAIN, 16));
        azkalDesc.setForeground(Color.WHITE);
        contentPane.add(azkalDesc);

        ImageIcon imageAkbar = createImageIcon("./credits/akbar.png");
        if (imageAkbar != null) {
            pic = new JLabel(imageAkbar);
            pic.setBounds(50, 1887, 150, 150);
            // Add mouse listener to the JLabel
            pic.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    // Open the link in the default web browser when the image is clicked
                    openLink("https://www.instagram.com/inotlusrabka");
                }
                @Override
                public void mouseEntered(MouseEvent e) {
                    // Change cursor to hand when the mouse enters the JLabel
                    setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                }
                @Override
                public void mouseExited(MouseEvent e) {
                    // Change cursor back to default when the mouse exits the JLabel
                    setCursor(Cursor.getDefaultCursor());
                }
            });
            contentPane.add(pic);
        } else {
            System.err.println("Could not load the image");
        }
        akbarDesc = new JLabel("<html>Mohammad Akbar Sultoni<br>" +
                "2210511041<br><br>" +
                "Roles:<br>" +
                "1. Lead Programmer<br>" +
                "2. UI/UX Designer</html>");
        akbarDesc.setBounds(233, 1869, 310, 150);
        akbarDesc.setFont(new Font("Bahnschrift", Font.PLAIN, 16));
        akbarDesc.setForeground(Color.WHITE);
        contentPane.add(akbarDesc);

        buttonEx = new JButton("Back");
        buttonEx.setBounds(412, 2095, 120, 50);
        contentPane.add(buttonEx);
        buttonEx.setForeground(Color.WHITE);
        buttonEx.setBackground(Color.DARK_GRAY);
        buttonEx.addActionListener(this);
        // Add the content pane to the scroll pane
        scrollPane.setViewportView(contentPane);
        // Set the unit increment for the vertical scrollbar
        scrollPane.getVerticalScrollBar().setUnitIncrement(20); // You can adjust this value to make scrolling faster
    }

    private ImageIcon createImageIcon(String path) {
        URL imgUrl = getClass().getClassLoader().getResource(path);
        if (imgUrl != null) {
            return new ImageIcon(imgUrl);
        } else {
            System.err.println("Couldn't find file: " + path);
            return null;
        }
    }

    private void openLink(String url) {
        try {
            Desktop.getDesktop().browse(new URL(url).toURI());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == buttonEx) {
            dispose();
            try {
                new mainMenu();
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        }
    }
    public class CustomWindowAdapter extends WindowAdapter {
        @Override
        public void windowClosing(WindowEvent e) {
            super.windowClosing(e);
            try {
                mainMenu.stopMusic();
                new mainMenu();
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        }
    }
}