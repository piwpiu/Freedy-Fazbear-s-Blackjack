import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
public class highScoreMenu extends JFrame implements ActionListener{
    private static JLabel highScore;
    private static JButton backButton;
    public highScoreMenu(){
        setTitle("High Score");
        setSize(400, 400);
        setLocationRelativeTo(null);
        setLayout(null);
        setVisible(true);
        setResizable(false);
        getContentPane().setBackground(new Color(53, 101, 77));
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        addWindowListener(new CustomWindowAdapter());

        highScore = new JLabel("High Score");
        highScore.setBounds(110, 25, 300,35);
        highScore.setForeground(Color.WHITE);
        highScore.setFont(new Font("Bahnschrift", Font.BOLD, 35));
        add(highScore);

        backButton = new JButton("Back");
        backButton.setBounds(140, 300, 100, 25);
        backButton.setForeground(Color.WHITE);
        backButton.setBackground(Color.DARK_GRAY);
        backButton.addActionListener(this);
        add(backButton);

        displayHighScore();
    }
    private void displayHighScore() {
        try (BufferedReader reader = new BufferedReader(new FileReader("users.csv"))) {

            String line;
            int lineCount = 0;
            int yPos = 65;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if(data.length == 2) {
                    String username = data[0].trim();
                    String highestStreak = data[1].trim();
                    if (lineCount >= 0) {
                        JLabel userScoreLabel = new JLabel(username + " - Score: " + highestStreak);
                        userScoreLabel.setBounds(110, yPos, 400, 35);
                        userScoreLabel.setForeground(Color.WHITE);
                        userScoreLabel.setFont(new Font("Bahnschrift", Font.PLAIN, 18));
                        add(userScoreLabel);
                        yPos += 40;
                    }
                    lineCount++;
                }
                if(lineCount == 5){
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == backButton) {
            dispose();
            try {
                new mainMenu();
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        }
    }
    public class CustomWindowAdapter extends WindowAdapter {
        @Override
        public void windowClosing(WindowEvent e) {
            super.windowClosing(e);
            try {
                mainMenu.stopMusic();
                new mainMenu();
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        }
    }
}
