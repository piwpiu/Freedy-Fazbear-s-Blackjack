import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.event.MouseInputAdapter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Random;
import javax.sound.sampled.*;
public class mainMenu extends JFrame implements ActionListener {
    private static JLabel gameTitle, shadowText, pic, welcomeUser,
            speakerLabel, highestStreak, highScoreLabel;
    private static JButton startButton, howToButton, aboutButton, quitButton;
    private static BufferedImage mainMenuPict, highScoreIcon, speakerIcon;
    private static boolean isMusicPlaying = true;
    private static Clip backgroundMusic;
    private static long clipTime;
    int newWidth, newHeight;
    private UserSession UserSession;
    public mainMenu() throws IOException {
        setTitle("Black Jack Card Game");
        setSize(600, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        setLayout(null);
        setVisible(true);
        getContentPane().setBackground(new Color(53,101,77));

        UserSession = new UserSession();
        UserSession.readUserInfo();

        Image i = Toolkit.getDefaultToolkit().getImage("blackjack-java-master/assets/logoFrame.png");
        setIconImage(i);

        gameTitle = new JLabel("BLACK JACK");
        gameTitle.setBounds(185, 35, 300,35);
        gameTitle.setForeground(Color.WHITE);
        gameTitle.setFont(new Font("Bahnschrift", Font.BOLD, 35));
        add(gameTitle);

        shadowText = new JLabel("BLACK JACK");
        shadowText.setBounds(190, 40, 300,35);
        shadowText.setForeground(Color.BLACK);
        shadowText.setFont(new Font("Bahnschrift", Font.BOLD, 35));
        add(shadowText);

        welcomeUser = new JLabel("Welcome, " + UserSession.getUsername());
        welcomeUser.setBounds(17, 8, 171, 29);
        welcomeUser.setForeground(Color.WHITE);
        welcomeUser.setFont(new Font("Bahnschrift", Font.PLAIN, 14));
        add(welcomeUser);

        highestStreak = new JLabel("Highest Streak: " + UserSession.getHighestStreak());
        highestStreak.setBounds(17, 25, 171, 29);
        highestStreak.setForeground(Color.BLACK);
        highestStreak.setFont(new Font("Bahnschrift", Font.BOLD, 12));
        add(highestStreak);

        mainMenuPict = ImageIO.read(new File("blackjack-java-master/assets/mainMenuPict.png"));
        pic = new JLabel(new ImageIcon(mainMenuPict));
        newWidth = 512;
        newHeight = 512;
        Image scaledImage = mainMenuPict.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
        ImageIcon icon = new ImageIcon(scaledImage);
        pic = new JLabel(icon);
        pic.setBounds(38, -70, newWidth, newHeight);
        add(pic);

        highScoreIcon = ImageIO.read(new File("blackjack-java-master/assets/hiScore.png"));
        highScoreLabel = new JLabel(new ImageIcon(highScoreIcon));
        newWidth = 40;
        newHeight = 40;
        Image scaledHS = highScoreIcon.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
        ImageIcon ic = new ImageIcon(scaledHS);
        highScoreLabel = new JLabel(ic);
        highScoreLabel.setBounds(60,510,newWidth, newHeight);
        add(highScoreLabel);

        highScoreLabel.addMouseListener(new MouseInputAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                dispose();
                new highScoreMenu();
            }
            @Override
            public void mouseEntered(MouseEvent e) {
                // Change cursor to indicate clickability
                setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            }
            @Override
            public void mouseExited(MouseEvent e) {
                // Change cursor back to default
                setCursor(Cursor.getDefaultCursor());
            }
        });

        speakerIcon = ImageIO.read(new File("blackjack-java-master/assets/speaker1.png"));
        speakerLabel = new JLabel(new ImageIcon(speakerIcon));
        newWidth = 40;
        newHeight = 40;
        Image scaledSP = speakerIcon.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
        ImageIcon ad = new ImageIcon(scaledSP);
        speakerLabel = new JLabel(ad);
        speakerLabel.setBounds(10,510,newWidth, newHeight);
        add(speakerLabel);

        speakerLabel.addMouseListener(new MouseInputAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                toggleMusic();
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                // Change cursor to indicate clickability
                setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                // Change cursor back to default
                setCursor(Cursor.getDefaultCursor());
            }
        });

        startButton = new JButton("Start");
        startButton.setBounds(230, 310, 125,55);
        startButton.setForeground(Color.WHITE);
        startButton.setBackground(Color.DARK_GRAY);
        startButton.setFont(new Font("Bahnschrift", Font.PLAIN, 20));
        startButton.addActionListener(this);
        add(startButton);

        howToButton = new JButton("How To Play");
        howToButton.setBounds(195, 370, 200,55);
        howToButton.setForeground(Color.WHITE);
        howToButton.setBackground(Color.DARK_GRAY);
        howToButton.setFont(new Font("Bahnschrift", Font.PLAIN, 20));
        howToButton.addActionListener(this);
        add(howToButton);

        aboutButton = new JButton("About");
        aboutButton.setBounds(230, 430, 125,55);
        aboutButton.setForeground(Color.WHITE);
        aboutButton.setBackground(Color.DARK_GRAY);
        aboutButton.setFont(new Font("Bahnschrift", Font.PLAIN, 20));
        aboutButton.addActionListener(this);
        add(aboutButton);

        quitButton = new JButton("Quit");
        quitButton.setBounds(230, 490, 125,55);
        quitButton.setForeground(Color.WHITE);
        quitButton.setBackground(Color.DARK_GRAY);
        quitButton.setFont(new Font("Bahnschrift", Font.PLAIN, 20));
        quitButton.addActionListener(this);
        add(quitButton);

        String[] songLists = {
                "blackjack-java-master/assets/audio/mainMenuAudio0.wav",
                "blackjack-java-master/assets/audio/mainMenuAudio1.wav",
                "blackjack-java-master/assets/audio/mainMenuAudio2.wav"
        };

        Random randomize = new Random();
        int numRand = randomize.nextInt(3);

        try {
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new File(songLists[numRand]));
            backgroundMusic = AudioSystem.getClip();
            backgroundMusic.open(audioInputStream);
            backgroundMusic.loop(Clip.LOOP_CONTINUOUSLY);
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == startButton) {
            dispose();
            BlackJack blackJackGame = new BlackJack();
            blackJackGame.startGame();
            blackJackGame.frame.setVisible(true);
        } else if (e.getSource() == howToButton) {
            dispose();
            stopMusic();
            new HowToPlayMenu();
        } else if (e.getSource() == aboutButton) {
            dispose();
            stopMusic();
            try {
                new AboutMenu();
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        } else if (e.getSource() == quitButton) {
            if (JOptionPane.showConfirmDialog(mainMenu.this,"Are you sure you want to exit?",
                    "BLACKJACK", JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION)
                System.exit(0);
        }
    }
    private ImageIcon createImageIcon(String path) {
        URL imgUrl = getClass().getClassLoader().getResource(path);
        if (imgUrl != null) {
            return new ImageIcon(imgUrl);
        } else {
            System.err.println("Couldn't find file: " + path);
            return null;
        }
    }

    static void stopMusic() {
        if (backgroundMusic.isRunning()) {
            clipTime = backgroundMusic.getMicrosecondPosition();
            backgroundMusic.stop();
            isMusicPlaying = true; // Reset the flag when stopping the music
        }
    }

    private void toggleMusic() {
        if (isMusicPlaying) {
            clipTime = backgroundMusic.getMicrosecondPosition();
            backgroundMusic.stop();
        } else {
            backgroundMusic.setMicrosecondPosition(clipTime);
            backgroundMusic.start();
        }
        isMusicPlaying = !isMusicPlaying;
    }

    private int getHighestStreak() {
        // Use userSession.getHighestStreak() instead of creating a new instance
        return UserSession.getHighestStreak();
    }
}