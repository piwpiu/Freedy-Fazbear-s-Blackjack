public class BlackjackCard extends BaseCard {
    BlackjackCard(String value, String type) {
        super(value, type);
    }
    @Override
    public int getValue() {
        if ("AJQK".contains(value)) {
            return value.equals("A") ? 1 : 10;
        }
        return Integer.parseInt(value);
    }
    @Override
    public boolean isAce() {
        return value.equals("A");
    }
    @Override
    public String getImagePath() {
        return "./cards/" + toString() + ".png";
    }
}