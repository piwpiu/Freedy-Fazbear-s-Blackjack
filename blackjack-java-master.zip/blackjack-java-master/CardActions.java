interface CardActions {
    int getValue();
    boolean isAce();
    String getImagePath();
}

abstract class BaseCard implements CardActions {
    String value;
    String type;
    BaseCard(String value, String type) {
        this.value = value;
        this.type = type;
    }

    @Override
    public String toString() {
        return value + "-" + type;
    }
}